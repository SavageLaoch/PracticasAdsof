package simulador;

public abstract class Observador {
	/**
	 * Actualiza los datos del observador
	 */
	public abstract void actualizar();

}
